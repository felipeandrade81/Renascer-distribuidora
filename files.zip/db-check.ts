// Testa a conexão com o banco (Neon, Supabase ou local) e mostra o que está configurado.  Uso: npm run db:check
import 'dotenv/config';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const host = (u?: string) => { try { return new URL(u ?? '').host; } catch { return '(não definido)'; } };

async function main() {
  console.log('DATABASE_URL →', host(process.env.DATABASE_URL));
  console.log('DIRECT_URL   →', host(process.env.DIRECT_URL));
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) console.log('⚠ JWT_SECRET ausente ou curto (mín. 32 caracteres): a API não sobe sem ele.');
  const t0 = Date.now();
  const [info] = await prisma.$queryRaw<{ db: string; version: string }[]>`SELECT current_database() AS db, version() AS version`;
  console.log(`✓ Conectado ao banco "${info.db}" em ${Date.now() - t0} ms`);
  console.log(' ', info.version.split(',')[0]);
  try {
    const [u, c, b] = await Promise.all([prisma.user.count(), prisma.company.count(), prisma.bankAccount.count()]);
    console.log(`✓ Tabelas criadas · usuários: ${u} · empresa: ${c} · contas bancárias: ${b}`);
    if (u === 0) console.log('  Nenhum usuário ainda: crie o administrador no primeiro acesso (POST /api/auth/setup) ou use SEED_ADMIN_EMAIL/SEED_ADMIN_PASSWORD no seed.');
  } catch {
    console.log('⚠ Conectou, mas as tabelas ainda não existem. Rode: npm run db:push   (e depois: npm run db:seed)');
  }
}
main().catch((e) => {
  console.error('✗ Não foi possível conectar:', String(e.message ?? e).split('\n').slice(-3).join(' ').slice(0, 300));
  console.error('  Confira: senha e host nas URLs do .env, "?sslmode=require", e se o projeto gratuito não está pausado.');
  process.exit(1);
}).finally(() => prisma.$disconnect());
