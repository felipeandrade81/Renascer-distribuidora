# Backend + Postgres gratuito (Neon ou Supabase) com autenticação de servidor

O backend (NestJS + Prisma) já está preparado. O que falta é você criar o banco gratuito e colar as duas URLs de
conexão no `.env`: ninguém, além de você, pode fazer essa parte, porque ela depende da sua conta.

## 1. Criar o banco (5 minutos)

**Neon** (neon.tech) → *Create project* → região mais próxima (ex.: São Paulo) → botão **Connect**:
- copie a URL com *Connection pooling* **ligado** → `DATABASE_URL`
- copie a URL com *Connection pooling* **desligado** → `DIRECT_URL`

**Supabase** (supabase.com) → *New project* → *Project Settings › Database › Connection string*:
- *Transaction pooler* (porta 6543) + `?pgbouncer=true` → `DATABASE_URL`
- *Session pooler* (porta 5432) → `DIRECT_URL`

> Os limites do plano gratuito (espaço, pausa por inatividade) mudam com o tempo: confira no site de cada serviço.
> Projetos gratuitos podem "dormir" e a primeira requisição demorar alguns segundos.

## 2. Configurar e criar as tabelas

```bash
cd backend
cp .env.example .env          # cole DATABASE_URL e DIRECT_URL; gere o JWT_SECRET: openssl rand -base64 48
npm install                   # também roda "prisma generate"
npm run db:push               # cria as tabelas no banco gratuito
npm run db:seed               # empresa (CNPJ 69.196.200/0001-68), conta Bradesco, WhatsApp do gerente, adquirentes
npm run db:check              # confirma a conexão e mostra o que existe
```

Opcional no seed: `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` (cria o administrador) e `SEED_DEMO=1` (dados de exemplo).
Para ter histórico de migrações em produção: `npx prisma migrate dev --name init` (na sua máquina) e `npm run db:deploy` no servidor.

## 3. Subir a API e criar o administrador

```bash
npm run start:dev                                   # http://localhost:3333/api
curl localhost:3333/api/auth/status                 # {"needsSetup":true}
curl -X POST localhost:3333/api/auth/setup -H 'Content-Type: application/json' \
  -d '{"name":"Seu Nome","email":"voce@empresa.com","password":"SenhaForte123"}'     # devolve o token
```

## 4. Como a autenticação funciona (no servidor)

- Senhas guardadas com **scrypt + salt**; login com limite de tentativas; token JWT de 8 h.
- **A cada requisição** o servidor confere no banco se o usuário está ativo e qual o perfil dele:
  desativar um usuário ou trocar o perfil vale na hora, sem esperar o token vencer.
- Permissões por perfil são aplicadas no servidor (`@Roles`): ADMIN, GERENTE, VENDEDOR, CAIXA, TECNICO_CAIXA, ESTOQUISTA, FINANCEIRO.
- Primeiro administrador: `POST /auth/setup` (só funciona enquanto não existir nenhum usuário).
- Cancelamento no PDV: `POST /authorize/cancel` confere a **senha de autorização do gerente** (separada da senha de login) e grava na auditoria.

| Rota | Quem | O que faz |
|---|---|---|
| `GET /auth/status` · `POST /auth/setup` · `POST /auth/login` | público | primeiro acesso e entrada |
| `GET /auth/me` · `PATCH /auth/password` | logado | dados e troca da própria senha |
| `/users` (GET, POST, PATCH, DELETE) | ADMIN | gerir usuários (protege o último administrador) |
| `PUT /authorize/password` · `GET /authorize/managers` · `POST /authorize/cancel` | Gerente · logado · operadores | senha de autorização e cancelamentos |
| `GET/PUT /company` | logado · GERENTE | dados fiscais e contábeis da empresa |
| `/bank-accounts` | logado · GERENTE/FINANCEIRO | contas bancárias e chave PIX (valida CNPJ, agência, conta e chave) |
| `/whatsapp-contacts` | GERENTE | números que recebem o aviso de cancelamento |
| `GET /audit` | GERENTE/FINANCEIRO | trilha de auditoria |

## 5. Publicar a API de graça (opcional)

Render, Railway ou Fly.io: *Build* `npm install && npm run build` · *Start* `npm run start:prod` · variáveis do `.env`
(`DATABASE_URL`, `DIRECT_URL`, `JWT_SECRET`, `FRONTEND_URL` com o endereço do seu site). Use sempre HTTPS.

## 6. Cuidados

- Nunca publique o `.env` (já está no `.gitignore`). Troque a senha do banco se ela vazar.
- `JWT_SECRET` forte e único. `FRONTEND_URL` só com os endereços que você usa.
- Ative os backups do provedor assim que houver dados reais.
- **Ainda não testado contra um banco real**: o código não foi executado aqui. Rode `npm run db:check` e
  `npm run build`; se algo falhar, a mensagem indica o que ajustar.

## 7. O que está ligado a quê

- **Frontend Next.js** (`/frontend`): login, Fornecedores e Compras já usam a API. As demais telas ainda usam dados de exemplo.
- **`renascer-sistema.html`**: página independente (guarda os dados no navegador ou no banco da plataforma de publicação);
  **não** usa este backend.
