import { BadRequestException, Body, ConflictException, Controller, Delete, Get, Param, Patch, Post, Put, Query } from '@nestjs/common';
import { Role } from '@prisma/client';
import { z } from 'zod';
import { crud, parse } from './common';
import { Roles } from './auth';
import { PrismaService } from './prisma.service';

const digits = (s: string) => s.replace(/\D/g, '');
export function cnpjOk(v: string) {
  const c = digits(v);
  if (c.length !== 14 || /^(\d)\1+$/.test(c)) return false;
  const dv = (base: string) => { let s = 0, p = base.length - 7; for (const n of base) { s += +n * p--; if (p < 2) p = 9; } const r = s % 11; return r < 2 ? 0 : 11 - r; };
  return dv(c.slice(0, 12)) === +c[12] && dv(c.slice(0, 13)) === +c[13];
}
const opt = z.string().trim().optional();

/* ───────── Dados da empresa (linha única) ───────── */
const companySchema = z.object({
  legalName: z.string().trim().min(3), tradeName: opt, cnpj: z.string().refine(cnpjOk, 'CNPJ inválido').transform(digits),
  size: opt, legalNature: opt, status: opt, cnae: opt, cnaesSecondary: opt, stateRegistration: opt, municipalRegistration: opt, taxRegime: opt,
  address: opt, email: z.string().email().optional(), phone: opt, openedAt: z.coerce.date().optional(), shareCapital: z.coerce.number().min(0).optional(),
  partners: opt, accountant: opt, crc: opt,
});

@Controller('company')
export class CompanyController {
  constructor(private prisma: PrismaService) {}
  @Get() get() { return this.prisma.company.findUnique({ where: { id: 'main' } }); }
  @Roles('GERENTE')
  @Put() save(@Body() b: unknown) { const d = parse(companySchema, b); return this.prisma.company.upsert({ where: { id: 'main' }, update: d, create: { id: 'main', ...d } }); }
}

/* ───────── Contas bancárias e PIX ───────── */
const pixOk = (tp: string, k: string) => tp === 'CNPJ' ? cnpjOk(k) : tp === 'E-mail' ? /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(k) && k.length <= 77
  : tp === 'Telefone' ? /^(\+?55)?\d{10,11}$/.test(k.replace(/[\s()-]/g, '')) : /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(k);
const pixNorm = (tp: string, k: string) => tp === 'CNPJ' ? digits(k) : tp === 'Telefone' ? '+55' + digits(k).replace(/^55(?=\d{10,11}$)/, '') : k.toLowerCase();

const bankSchema = z.object({
  bankName: z.string().trim().min(3), agency: z.string().trim().regex(/^\d{3,5}(-?[\dxX])?$/, 'Agência inválida'), account: z.string().trim().regex(/^\d{3,11}-?[\dxX]$/, 'Conta inválida (com dígito)'),
  accountType: z.enum(['Corrente', 'Poupança', 'Pagamento']).default('Corrente'), holderName: z.string().trim().min(3), holderCnpj: z.string().refine(cnpjOk, 'CNPJ do titular inválido').transform(digits),
  pixKeyType: z.enum(['CNPJ', 'E-mail', 'Telefone', 'Aleatória']).default('CNPJ'), pixKey: z.string().trim().optional(),
  acceptsCredit: z.boolean().default(true), acceptsDebit: z.boolean().default(true), acceptsCash: z.boolean().default(true), acceptsPix: z.boolean().default(true),
  isPrimary: z.boolean().default(false), active: z.boolean().default(true),
}).superRefine((d, c) => {
  if (d.acceptsPix && !d.pixKey) c.addIssue({ code: 'custom', path: ['pixKey'], message: 'Informe a chave PIX' });
  if (d.pixKey && !pixOk(d.pixKeyType, d.pixKey)) c.addIssue({ code: 'custom', path: ['pixKey'], message: `Chave PIX inválida para o tipo ${d.pixKeyType}` });
  if (!(d.acceptsCredit || d.acceptsDebit || d.acceptsCash || d.acceptsPix)) c.addIssue({ code: 'custom', path: ['acceptsCash'], message: 'Marque ao menos um meio de recebimento' });
});

@Controller('bank-accounts')
export class BankController {
  constructor(private prisma: PrismaService) {}
  @Get() list() { return this.prisma.bankAccount.findMany({ orderBy: [{ isPrimary: 'desc' }, { createdAt: 'asc' }] }); }

  private async normalize(raw: unknown) {
    const d = parse(bankSchema, raw);
    const company = await this.prisma.company.findUnique({ where: { id: 'main' } });
    if (company && company.cnpj !== d.holderCnpj) throw new ConflictException(`A conta deve estar em nome da empresa (CNPJ ${company.cnpj})`);
    return { ...d, pixKey: d.pixKey ? pixNorm(d.pixKeyType, d.pixKey) : null };
  }

  @Roles('GERENTE', 'FINANCEIRO')
  @Post() async create(@Body() b: unknown) {
    const d = await this.normalize(b);
    return this.prisma.$transaction(async (tx) => {
      const first = (await tx.bankAccount.count()) === 0, primary = d.isPrimary || first;
      if (primary) await tx.bankAccount.updateMany({ data: { isPrimary: false } });
      return tx.bankAccount.create({ data: { ...d, isPrimary: primary } }); // conta repetida → 409
    });
  }

  @Roles('GERENTE', 'FINANCEIRO')
  @Patch(':id') async update(@Param('id') id: string, @Body() b: unknown) {
    const cur = await this.prisma.bankAccount.findUniqueOrThrow({ where: { id } });
    const { id: _i, createdAt: _c, pixKey, ...rest } = cur;
    const d = await this.normalize({ ...rest, pixKey: pixKey ?? undefined, ...(b as object) });
    return this.prisma.$transaction(async (tx) => {
      if (d.isPrimary) await tx.bankAccount.updateMany({ where: { id: { not: id } }, data: { isPrimary: false } });
      return tx.bankAccount.update({ where: { id }, data: d });
    });
  }

  @Roles('GERENTE', 'FINANCEIRO')
  @Delete(':id') async remove(@Param('id') id: string) {
    await this.prisma.$transaction(async (tx) => {
      const gone = await tx.bankAccount.delete({ where: { id } });
      if (gone.isPrimary) { const next = await tx.bankAccount.findFirst({ orderBy: { createdAt: 'asc' } }); if (next) await tx.bankAccount.update({ where: { id: next.id }, data: { isPrimary: true } }); }
    });
    return { ok: true };
  }
}

/* ───────── WhatsApp do gerente e auditoria ───────── */
const r = (...x: Role[]) => x;
const waSchema = z.object({
  name: z.string().trim().min(2),
  phone: z.string().transform(digits).refine((d) => /^(55)?\d{10,11}$/.test(d), 'Número inválido: use DDD + 8 ou 9 dígitos').transform((d) => (d.length > 11 ? d : '55' + d)),
  active: z.boolean().default(true),
});
export const WhatsappController = crud('whatsapp-contacts', 'whatsappContact', waSchema, { search: ['name', 'phone'], read: r('GERENTE', 'VENDEDOR', 'CAIXA', 'TECNICO_CAIXA'), write: r('GERENTE') });

@Controller('audit')
@Roles('GERENTE', 'FINANCEIRO')
export class AuditController {
  constructor(private prisma: PrismaService) {}
  @Get() list(@Query('take') take = '100') { return this.prisma.auditLog.findMany({ orderBy: { createdAt: 'desc' }, take: Math.min(+take || 100, 500) }); }
}
