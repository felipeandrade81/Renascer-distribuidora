import { ConflictException, Body, Controller, Delete, Get, HttpException, Param, Patch, Post, Put, Req, UnauthorizedException } from '@nestjs/common';
import { z } from 'zod';
import { AuthUser, Roles, hashPassword, pwSchema, verifyPassword } from './auth';
import { parse } from './common';
import { PrismaService } from './prisma.service';

const ROLES = ['ADMIN', 'GERENTE', 'VENDEDOR', 'CAIXA', 'TECNICO_CAIXA', 'ESTOQUISTA', 'FINANCEIRO'] as const;
const sel = { id: true, name: true, email: true, role: true, active: true, lastLogin: true, createdAt: true, authHash: true } as const;
const pub = (u: { authHash: string | null } & Record<string, unknown>) => { const { authHash, ...r } = u; return { ...r, hasAuthPassword: !!authHash }; };

const createSchema = z.object({ name: z.string().trim().min(3), email: z.string().email(), password: pwSchema, role: z.enum(ROLES), active: z.boolean().default(true) });
const updateSchema = z.object({ name: z.string().trim().min(3), email: z.string().email(), password: pwSchema, role: z.enum(ROLES), active: z.boolean() }).partial();

/** Gestão de usuários: somente ADMIN. As senhas nunca voltam nas respostas. */
@Controller('users')
@Roles('ADMIN')
export class UsersController {
  constructor(private prisma: PrismaService) {}
  private audit(u: AuthUser, action: string, detail: string) { return this.prisma.auditLog.create({ data: { userId: u.sub, userName: u.name, action, detail } }).catch(() => undefined); }
  private async isLastAdmin(id: string) {
    const u = await this.prisma.user.findUniqueOrThrow({ where: { id } });
    return u.role === 'ADMIN' && u.active && (await this.prisma.user.count({ where: { role: 'ADMIN', active: true } })) === 1;
  }

  @Get() async list() { return (await this.prisma.user.findMany({ select: sel, orderBy: { createdAt: 'asc' } })).map(pub); }

  @Post() async create(@Body() b: unknown, @Req() req: { user: AuthUser }) {
    const d = parse(createSchema, b); // e-mail repetido → 409 (filtro do Prisma)
    const u = await this.prisma.user.create({ data: { name: d.name, email: d.email.toLowerCase(), password: hashPassword(d.password), role: d.role, active: d.active }, select: sel });
    await this.audit(req.user, 'Usuário criado', `${u.name} · ${u.role}`);
    return pub(u);
  }

  @Patch(':id') async update(@Param('id') id: string, @Body() b: unknown, @Req() req: { user: AuthUser }) {
    const d = parse(updateSchema, b);
    if ((await this.isLastAdmin(id)) && ((d.role && d.role !== 'ADMIN') || d.active === false)) throw new ConflictException('Mantenha ao menos um administrador ativo');
    if (id === req.user.sub && d.active === false) throw new ConflictException('Você não pode desativar o próprio usuário');
    const { password, email, ...rest } = d;
    const u = await this.prisma.user.update({ where: { id }, select: sel, data: { ...rest, ...(email ? { email: email.toLowerCase() } : {}), ...(password ? { password: hashPassword(password) } : {}) } });
    await this.audit(req.user, 'Usuário alterado', `${u.name} · ${u.role}${password ? ' · nova senha' : ''}`);
    return pub(u);
  }

  @Delete(':id') async remove(@Param('id') id: string, @Req() req: { user: AuthUser }) {
    if (id === req.user.sub) throw new ConflictException('Você não pode excluir o próprio usuário');
    if (await this.isLastAdmin(id)) throw new ConflictException('Mantenha ao menos um administrador ativo');
    const u = await this.prisma.user.delete({ where: { id } }); // com vendas/compras vinculadas → 409: desative em vez de excluir
    await this.audit(req.user, 'Usuário excluído', u.name);
    return { ok: true };
  }
}

const DUMMY = `${'0'.repeat(32)}:${'0'.repeat(64)}`;

/** Autorização de cancelamentos no PDV: o gerente digita a senha de autorização (diferente da senha de login). */
@Controller('authorize')
export class AuthorizeController {
  private fails = new Map<string, { n: number; until: number }>();
  constructor(private prisma: PrismaService) {}

  /** Quem pode autorizar (Gerente/Admin ativos com senha de autorização cadastrada). */
  @Get('managers') managers() {
    return this.prisma.user.findMany({ where: { active: true, role: { in: ['ADMIN', 'GERENTE'] }, authHash: { not: null } }, select: { id: true, name: true }, orderBy: { name: 'asc' } });
  }

  /** O próprio gerente cadastra/altera a sua senha de autorização. */
  @Roles('GERENTE')
  @Put('password') async setPassword(@Body() b: unknown, @Req() req: { user: AuthUser }) {
    const d = parse(z.object({ current: z.string().optional(), password: pwSchema }), b);
    const u = await this.prisma.user.findUniqueOrThrow({ where: { id: req.user.sub } });
    if (u.authHash && !(d.current && verifyPassword(d.current, u.authHash))) throw new UnauthorizedException('Senha de autorização atual incorreta');
    await this.prisma.user.update({ where: { id: u.id }, data: { authHash: hashPassword(d.password) } });
    await this.prisma.auditLog.create({ data: { userId: u.id, userName: u.name, action: `Senha de autorização ${u.authHash ? 'alterada' : 'cadastrada'}` } });
    return { ok: true };
  }

  @Roles('GERENTE', 'VENDEDOR', 'CAIXA', 'TECNICO_CAIXA')
  @Post('cancel') async cancel(@Body() b: unknown, @Req() req: { user: AuthUser }) {
    const d = parse(z.object({ managerId: z.string().uuid(), password: z.string().min(1), reason: z.string().trim().min(5), subject: z.string().trim().min(3).max(300) }), b);
    const key = `${req.user.sub}|${d.managerId}`, f = this.fails.get(key), now = Date.now();
    if (f && f.n >= 3 && f.until > now) throw new HttpException('Muitas tentativas. Aguarde 1 minuto.', 429);
    const m = await this.prisma.user.findFirst({ where: { id: d.managerId, active: true, role: { in: ['ADMIN', 'GERENTE'] }, authHash: { not: null } } });
    const ok = verifyPassword(d.password, m?.authHash ?? DUMMY) && !!m;
    if (!ok || !m) {
      this.fails.set(key, { n: (f && f.until > now ? f.n : 0) + 1, until: now + 60_000 });
      throw new UnauthorizedException('Senha de autorização incorreta');
    }
    this.fails.delete(key);
    await this.prisma.auditLog.create({ data: { userId: m.id, userName: m.name, action: 'Cancelamento autorizado', detail: `${d.subject} · operador ${req.user.name} · motivo: ${d.reason}` } });
    return { authorized: true, manager: { id: m.id, name: m.name } };
  }
}
